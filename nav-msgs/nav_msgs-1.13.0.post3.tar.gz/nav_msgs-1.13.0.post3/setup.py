from setuptools import find_packages, setup
setup(name='nav_msgs', version='1.13.0.post3', packages=find_packages(),
      install_requires=['genpy>=0.6.14,<2000'])