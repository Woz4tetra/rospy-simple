from setuptools import find_packages, setup
setup(name='roscpp', version='1.15.11', packages=find_packages(),
      install_requires=['genpy>=0.6.14,<2000'])